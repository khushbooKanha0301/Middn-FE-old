import React, { useState, useEffect } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import { CameraIcon } from "./SVGIcon";
import { useSelector } from "react-redux";
import { userDetails, userGetData, userGetFullDetails } from '../store/slices/AuthSlice';

import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { FaTrashAlt } from "react-icons/fa";
import { useDispatch } from 'react-redux';
import jwtAxios from "../service/jwtAxios"
import { notificationSuccess } from "../store/slices/notificationSlice";

function simulateNetworkRequest() {
    return new Promise((resolve) => setTimeout(resolve, 2000));
}


export const EditProfileView = (props) => {
    const dispatch = useDispatch();

    const [country, setCountry] = useState();
    const [errFname, setErrFname] = useState(null);
    const [errLname, setErrLname] = useState(null);
    const [fname, setFname] = useState(null);
    const [lname, setLname] = useState(null);
    const [bio, setBio] = useState(null);
    const [profile, setProfile] = useState('');
    const [profileUrl, setProfileUrl] = useState('');
    const [location, setLocation] = useState(null);
    const [imageSrc, setImageSrc] = useState('');
    const [imageError, setImageError] = useState(null);
    const [isLoading, setLoading] = useState(false);
    const [countryCode, setCountryCode] = useState("");
    const userData = useSelector(userDetails);
    const userDetailsAll = useSelector(userGetFullDetails);
    const countryDetails = useSelector((state) => state.auth.countryDetails)

    useEffect(() => {
        if (countryDetails) {
            setCountry(countryDetails?.country_name);
            setCountryCode(countryDetails?.country_code);
        }
    }, [countryDetails]);



    useEffect(() => {
        if (userDetailsAll) {
            let user = userDetailsAll
            setFname(user?.fname ? user?.fname : null);
            setLname(user?.lname ? user?.lname : null);
            setLocation(user?.location ? user?.location : null);
            setBio(user?.bio ? user?.bio : null);
            setProfile(user?.profile ? user?.profile : null);
            setImageSrc(user?.imageUrl ? user?.imageUrl : null)
        }
    }, [userDetailsAll]);


    const onChange = (e) => {
        if (e.target.name == 'fname') {
            if (!e.target.value) {
                setErrFname('Please Enter First name');
            } else {
                setErrFname(null);
            }
            setFname(e.target.value)
        } else if (e.target.name == 'lname') {
            if (!e.target.value) {
                setErrLname('Please Enter Last name');
            } else {
                setErrLname(null);
            }
            setLname(e.target.value)
        } else if (e.target.name == 'location') {
            setLocation(e.target.value)
        } else if (e.target.name == 'bio') {
            setBio(e.target.value)
        } else if (e.target.name == 'profile') {
            const file = e.target.files[0];
            const reader = new FileReader();
            if (file && !file.type.includes('image/')) {
                setImageError('Please select a valid image file');
                return;
            } else {
                setImageError(null);
            }
            reader.onload = () => {
                setImageSrc(reader.result);
            }

            if (file) {
                reader.readAsDataURL(file);
            }

            setProfile(e.target.files[0])
        }
    };

    const onDeleteImage = async () => {
        setImageSrc('');
        setProfileUrl('');
        setProfile('');
    }

    const submitHandler = async () => {
        setLoading(true)
        if (!fname) {
            setErrFname('Please Enter First name')
        }
        if (!lname) {
            setErrLname('Please Enter Last name')
        }
        if (!errFname && !errLname && fname && lname) {
            setErrFname(null)
            setErrLname(null)


            let formSubmit = {
                fname: fname,
                lname: lname,
                location: location,
                bio: bio,
                profile: profile
            }

            let updateUser = await jwtAxios.put(`/users`, formSubmit, {
                headers: {
                    'Content-Type': "multipart/form-data",
                }
            })
            if (updateUser) {
                dispatch(userGetData(userData.userid)).unwrap()
                dispatch(notificationSuccess("User profile update successfully !"))
                props.onHide()
                // toast.success('user profile update successfully !', {
                //     position: "bottom-right",
                //     autoClose: 3000,
                //     hideProgressBar: true,
                //     closeOnClick: true,
                //     pauseOnHover: true,
                //     draggable: true,
                //     progress: undefined,
                //     theme: "dark",
                // });
            }
        }

    };
    useEffect(() => {
        if (isLoading) {
            simulateNetworkRequest().then(() => {
                setLoading(false);
            });
        }
    }, [isLoading]);


    const flagUrl = countryCode ? `https://flagcdn.com/h40/${countryCode?.toLowerCase()}.png` : ""

    return (
        <Modal
            {...props}
            dialogClassName="login-modal"
            backdropClassName="login-modal-backdrop"
            aria-labelledby="contained-modal"
            backdrop="static"
            keyboard={false}
            centered
        >
            <Modal.Body>
                <h4>Edit Profile</h4>
                <Form className="mt-4">

                    <Form.Group controlId="formFile" className="file-uploader" style={{ display: "flex", alignItems: "center" }}>
                        <Form.Label>  <img src={imageSrc ? imageSrc : profileUrl || require('../content/images/avatar.png')} id="output" alt={imageSrc || profile ? profile : "No Image"} width="135" height="135" />
                            <CameraIcon width="16" height="15" />

                        </Form.Label>
                        <Form.Control type="file" name='profile' accept="image/png,image/jpeg,image/jpg" onChange={(e) => onChange(e)} />
                        {profile && <FaTrashAlt style={{ color: 'red', fontSize: '30px', marginLeft: "14px" }} onClick={(e) => onDeleteImage(e)} />}
                    </Form.Group>
                    {imageError && <p className="text-danger text-center">{imageError}</p>}
                    <Form.Group className="form-group">
                        <Form.Label className="mb-1">First name (required)</Form.Label>
                        <Form.Control type="text" placeholder="First Name" name='fname' value={fname} onChange={(e) => onChange(e)} />
                        {errFname && <p className="error">{errFname}</p>}
                    </Form.Group>
                    <Form.Group className="form-group">
                        <Form.Label className="mb-1">Last name (required)</Form.Label>
                        <Form.Control type="text" placeholder="Last Name" name='lname' value={lname} onChange={(e) => onChange(e)} />
                        {errLname && <p className="error">{errLname}</p>}
                    </Form.Group>
                    <Form.Group className="form-group">
                        <Form.Label className="mb-1">Location</Form.Label>
                        <div className="input-flag">
                            {flagUrl ? <img src={flagUrl} alt="Flag" style={{ weight: "20px", height: "20px" }} /> : 'No Flag'}
                            <Form.Control type="text" placeholder="Location" name='location' value={country} onChange={(e) => onChange(e)} readOnly />
                        </div>
                    </Form.Group>
                    <Form.Group className="form-group">
                        <Form.Label className="mb-1">Bio</Form.Label>
                        <Form.Control type="text" placeholder="Add Your Experience....." name='bio' value={bio} onChange={(e) => onChange(e)} />
                    </Form.Group>
                    <p className="help-text">Any details such as age, occupation or city etc.<br />
                        Example: 21 y.o. crypto trader</p>
                    <div className="form-action-group">
                        <Button variant="primary" disabled={isLoading}
                            onClick={!isLoading ? submitHandler : null} >{isLoading ? 'Loading…' : 'Submit'}</Button>
                        <Button variant="secondary" onClick={props.onHide}>
                            Cancel
                        </Button>
                    </div>
                </Form>
            </Modal.Body>
        </Modal>
    );
};

export default EditProfileView;
