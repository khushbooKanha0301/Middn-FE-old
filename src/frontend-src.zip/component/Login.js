import React, { useEffect } from "react";
import { useState } from "react";
import { Modal, Button, Row, Col, Form } from "react-bootstrap";
import { useWeb3React } from "@web3-react/core";
import { connectors } from "../connectors";
import Fortmatic from 'fortmatic';
import Web3 from 'web3';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useDispatch } from 'react-redux'
import { checkAuth, logoutAuth, userDetails } from '../store/slices/AuthSlice'
import { useSelector } from "react-redux";
import apiConfig from "../config/config"
import { useNavigate } from 'react-router-dom';
import { notificationSuccess } from "../store/slices/notificationSlice";

export const LoginView = (props) => {
	const [checkValue, setCheckValue] = useState(null)
	const [accountAddress, setAccountAddress] = useState('');
	const [userchainId, SetUserChainId] = useState(null);
	const [newChainId, setNewChainId] = useState(null)
	const dispatch = useDispatch();
	const navigate = useNavigate();

	const userData = useSelector(userDetails)
	const {
		library,
		chainId,
		account,
		activate,
		deactivate,
	} = useWeb3React();
	const { ethereum } = window;
	const setProvider = (type) => {
		window.localStorage.setItem("provider", type);
	};


	useEffect(() => {
		const checkIfWalletIsConnected = async () => {
			try {
				const accounts = await ethereum.request({ method: 'eth_accounts' });

				if (accounts !== 0) {
					let account = accounts[0] ? accounts[0] : userData.address ? userData.address : null;
					if (account)
						setAccountAddress(account)
				}
			} catch (error) {
			}
		}
		let authToken = userData.authToken ? userData.authToken : null
		if (authToken) {
			checkIfWalletIsConnected();
		}
	}, [ethereum, userData.authToken, userData.address]);
	useEffect(() => {
		if (chainId) {
			SetUserChainId(chainId)
		}
	}, [chainId])
	ethereum && ethereum.on('chainChanged', networkId => {
		if ((userchainId !== null) && (userchainId !== networkId)) {
			setNewChainId(networkId)
		}
	});
	useEffect(() => {
		if (newChainId && (userchainId !== null) && (userchainId !== newChainId)) {
			dispatch(notificationSuccess("Network changed successfully !"))

			// toast.success('Network changed successfully !', {
			// 	position: "bottom-right",
			// 	autoClose: 3000,
			// 	hideProgressBar: true,
			// 	closeOnClick: true,
			// 	pauseOnHover: true,
			// 	draggable: true,
			// 	progress: undefined,
			// 	theme: "dark"
			// });
		}

	}, [newChainId])
	useEffect(() => {
		props.handleaccountaddress(accountAddress)
	}, [accountAddress])

	useEffect(() => {
		if (account) {
			let checkAuthParams = { account: account, library: library, checkValue: checkValue }
			dispatch(checkAuth(checkAuthParams)).unwrap()
		}
	}, [account])
	const refreshState = () => {
		window.localStorage.setItem("provider", undefined);
		window.localStorage.removeItem('userData')
	};
	useEffect(() => {
		if (props.isSign === true) {
			disconnect()
			dispatch(notificationSuccess("User logout successfully !"))			
			// toast.error('user logout successfully !', {
			// 	position: "bottom-right",
			// 	autoClose: 3000,
			// 	hideProgressBar: true,
			// 	closeOnClick: true,
			// 	pauseOnHover: true,
			// 	draggable: true,
			// 	progress: undefined,
			// 	theme: "dark",
			// });
		}
	}, [props.isSign])

	const disconnect = () => {
		deactivate();
		setAccountAddress('')
		navigate('/')
		dispatch(logoutAuth()).unwrap()
		refreshState()
	};
	const fortmatic = async () => {
		const fm = await new Fortmatic(apiConfig.FORTMATIC_KEY);
		window.web3 = await new Web3(fm.getProvider());
		await window.web3.eth.getAccounts((error, accounts) => {
			if (error) {
				throw error;
			}
			let checkAuthParams = { account: accounts[0], library: library, checkValue: checkValue }
			dispatch(checkAuth(checkAuthParams)).unwrap()
			setAccountAddress(accounts[0])
		});

	};
	const submitHandler = async (event) => {
		if (!!account) {
			disconnect()
		}
		event.preventDefault();
		switch (checkValue) {
			case 'wallet_connect':
				activate(connectors.walletConnect);
				setProvider("walletConnect");
				break;

			case 'meta_mask':
				activate(connectors.injected);
				setProvider("injected");
				break;
			case 'coinbase_wallet':
				activate(connectors.coinbaseWallet);
				setProvider("coinbaseWallet");
				break;

			case 'fortmatic':
				fortmatic()
				setProvider("fortmatic")
				break;
			default:
				break
		}
		props.onHide()
	};
	const onChange = (event) => {
		const { value } = event.target;
		setCheckValue(value)
	};
	return (
		<>
			{props.show &&
				<Modal
					{...props}
					dialogClassName="login-modal"
					backdropClassName="login-modal-backdrop"
					aria-labelledby="contained-modal"
					backdrop="static"
					keyboard={false}
					centered
				>
					<Modal.Body>
						<h4>Connect Wallet</h4>
						<p>
							Connect with one of our available wallet providers or create a new
							one.
						</p>
						<Form onSubmit={submitHandler}>
							<Row>
								<Col md="6">
									<Form.Check
										className="login-option"
										label={
											<>
												<img
													src={require('../content/images/wallet-connect.png')}
													alt="WalletConnect"
												/>{" "}
												WalletConnect
											</>
										}
										name="group1"
										type="radio"
										id="loginoption1"
										value={'wallet_connect'}
										onChange={onChange}
									/>
								</Col>
								<Col md="6">
									<Form.Check
										className="login-option"
										label={
											<span>
												<img
													src={require('../content/images/metamask.png')}
													alt="Metamask"
												/>{" "}
												Metamask
											</span>
										}
										value={'meta_mask'}
										name="group1"
										type="radio"
										id="loginoption2"
										onChange={onChange}
									/>
								</Col>
								<Col md="6">
									<Form.Check
										className="login-option"
										label={
											<span>
												<img
													src={require('../content/images/coinbase-wallet.png')}
													alt="Coinbase Wallet"
												/>{" "}
												Coinbase Wallet
											</span>
										}
										onChange={onChange}
										value={'coinbase_wallet'}
										name="group1"
										type="radio"
										id="loginoption3"
									/>
								</Col>
								<Col md="6">
									<Form.Check
										className="login-option"
										label={
											<span>
												<img
													src={require('../content/images/fortmatic.png')}
													alt="Fortmatic"
												/>{" "}
												Fortmatic
											</span>
										}
										onChange={onChange}
										value={'fortmatic'}
										name="group1"
										type="radio"
										id="loginoption4"
									/>
								</Col>
							</Row>
							<div className="form-action-group">
								<Button variant="primary" type='submit'  >Connect Wallet</Button>
								<Button variant="secondary" onClick={props.onHide}>
									Cancel
								</Button>
							</div>
						</Form>
					</Modal.Body>
				</Modal>
			}
		</>

	);
};
export default LoginView;
