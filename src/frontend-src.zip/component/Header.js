import React, { useState, useEffect } from "react";
import { Nav, Navbar, NavDropdown } from "react-bootstrap";
import { userDetails, userGetFullDetails } from '../store/slices/AuthSlice';


import {
	NotificationIcon,
	BellIcon,
	UserIcon,
	SettingIcon,
	LogoutIcon,
	LoginIcon
} from "./SVGIcon";
import { Link } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import { useDispatch, useSelector } from "react-redux";
import { hideAddress } from '../utils';

export const Header = (props) => {
	const dispatch = useDispatch();
	const [position, setPosition] = useState(window.pageYOffset);
	const [visible, setVisible] = useState(true);
	const [profile, setProfile] = useState(require("../content/images/avatar.png"));
	const acAddress = useSelector(userDetails);
	let usergetdata = useSelector(userGetFullDetails);


	useEffect(() => {
		const handleScroll = () => {
			let moving = window.pageYOffset;
			setVisible(position > moving);
			setPosition(moving);
		};
		window.addEventListener("scroll", handleScroll);
		return () => {
			window.removeEventListener("scroll", handleScroll);
		};
	});

	const cls = visible ? "visible" : "hidden";
	return (
		<div className={`header d-flex ${cls}`}>
			<ToastContainer />
			<Navbar.Toggle
				onClick={props.clickHandler}
				className="d-block d-md-none"
				aria-controls="basic-navbar-nav"
			/>
			<Nav className="ms-auto" as="ul">
				<Nav.Item as="li">
					<Nav.Link as={Link} to="/chat">
						<NotificationIcon width="26" height="24" />
						<span className="notification-badge">2</span>
					</Nav.Link>
				</Nav.Item>
				<Nav.Item as="li">
					<Nav.Link as={Link} to="/notification">
						<BellIcon width="20" height="22" />
						<span className="notification-badge">2</span>
					</Nav.Link>
				</Nav.Item>
				<Nav.Item as="li" onClick={props.clickModalHandler} className="login-menu">
					{acAddress && <span className="user-name d-none d-md-block">{hideAddress(acAddress?.account, 5)}</span>}
					<span className="login-btn d-flex d-md-none"><LoginIcon width="18" height="18" /></span>
				</Nav.Item>
				{acAddress && acAddress?.authToken &&
					<NavDropdown
						as="li"
						title={
							<img className="rounded-circle" style={{ width: "48px", height: "48px" }} src={usergetdata?.imageUrl ? usergetdata?.imageUrl : require("../content/images/avatar.png")} alt="No Profile" />
						}
						id="nav-dropdown"
					>
						{usergetdata && usergetdata?.wallet_address ? (
							<NavDropdown.Item as={Link} 
							to={`/profile/${usergetdata.wallet_address}`}>
								<UserIcon width="18" height="18" />
								Profile
							</NavDropdown.Item>
						)
							:
							<NavDropdown.Item as={Link} to={`/profile`}>
								<UserIcon width="18" height="18" />
								Profile
							</NavDropdown.Item>
						}
						<NavDropdown.Item as={Link} to="/settings">
							<SettingIcon width="18" height="18" />
							Account settings
						</NavDropdown.Item>
						<NavDropdown.Item onClick={props.signOut} >
							<LogoutIcon width="18" height="18" />
							Sign out
						</NavDropdown.Item>
					</NavDropdown>}
			</Nav>
		</div>
	);
};

export default Header;
