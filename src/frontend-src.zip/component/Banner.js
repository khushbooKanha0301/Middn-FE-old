import React from "react";
import { Card, Button } from "react-bootstrap";
export const Banner = () => {
  return (
    <Card className="cards-dark banner">
      <Card.Body>
        <div className="banner-contain">
          <Button variant="primary">Mkoon App</Button>
          <Card.Title as="h1">Time to build your reputation</Card.Title>
          <Card.Text>
            Customize your profile and start sharing it, We secure the rest,
            your customers will love it
          </Card.Text>
        </div>
      </Card.Body>
    </Card>
  );
};

export default Banner;
