import React from 'react';
import Highcharts from "highcharts/highstock";
import HighchartsReact from "highcharts-react-official";
import { DownArrowIcon } from './SVGIcon';
const colors = ['#E55F35'];
const options = {
    chart: {
        type: "spline",
        colors: colors,
        height: 50,
        width:80,
        backgroundColor: null,
        margin: [0, 10, 0, 0],
    },
    colors: colors,
    title: {
        text: null
    },
    tooltip: {
        enabled: false
    },
    credits: {
        enabled: false
    },
    xAxis: {
        visible: false,
    },
    yAxis: {
        visible: false,
    },
    plotOptions: {
        series: {
            marker: {
                enabled: false,
                states: {
                    hover: {
                        enabled: false
                    }
                }
            }
        }
    },
    series: [
        {
            showInLegend: false,
            data: [1, 2, 1, 3, 3.2]
        }
    ]
};
export const ThisMonth = () => {
    return (
        <>
        <div className="d-inline-flex position-relative">
        <HighchartsReact highcharts={Highcharts} options={options} />
        <div className="month-arrow">
            <DownArrowIcon width="16" height="16" /> 6%
        </div>
        </div>
        <div className="charts-label">This month</div>
        </>
    );
}

export default ThisMonth;
