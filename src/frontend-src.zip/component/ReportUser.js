import React from "react";
import { Modal, Button, Form } from "react-bootstrap";
import { CheckmarkIcon } from "./SVGIcon";

export const ReportUserView = (props) => {
    return (
        <Modal
            {...props}
            dialogClassName="login-modal"
            backdropClassName="login-modal-backdrop"
            aria-labelledby="contained-modal"
            backdrop="static"
            keyboard={false}
            centered
        >
            <Modal.Header closeButton>
                <Modal.Title>Report User</Modal.Title>
            </Modal.Header>
            <Modal.Body className="pt-4">
                <h4>Report this user</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                <Form className="mt-4">
                    <Form.Group className="custom-input">
                        <Form.Control type="text" placeholder="Lorem Ipsum" />
                        <div className="checkmark">
                            <CheckmarkIcon width="10" height="8" />
                        </div>
                    </Form.Group>
                    <Form.Group className="custom-input">
                        <Form.Control type="text" placeholder="Lorem Ipsum" />
                        <div className="checkmark">
                            <CheckmarkIcon width="10" height="8" />
                        </div>
                    </Form.Group>
                    <Form.Group className="custom-input">
                        <Form.Control type="text" placeholder="Lorem Ipsum" />
                        <div className="checkmark">
                            <CheckmarkIcon width="10" height="8" />
                        </div>
                    </Form.Group>
                    <Form.Group className="form-group">
                        <Form.Label className="mb-1">Other reason</Form.Label>
                        <Form.Control type="text" placeholder="Other reason" />
                    </Form.Group>
                    <div className="form-action-group">
                        <Button variant="primary">Submit</Button>
                        <Button variant="secondary" onClick={props.onHide}>
                            Cancel
                        </Button>
                    </div>
                </Form>
            </Modal.Body>
        </Modal>
    );
};

export default ReportUserView;
