import React, { useState } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { userGetFullDetails } from '../store/slices/AuthSlice';
import apiConfig from "../config/config"
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useHistory } from "react-router-dom";
import { notificationSuccess } from "../store/slices/notificationSlice";
import jwtAxios from "../service/jwtAxios";

export const MessageView = (props) => {
    const [content, SetContent] = useState(null)
    const [errContent, setErrContent] = useState(null);
    const usergetdata = useSelector(userGetFullDetails);
    const dispatch = useDispatch();


    const onChangeMessage = (e) =>{
        SetContent(e.target.value)
    }
    const onSubmit= async () =>{
        if (!content) {
            setErrContent('Please Enter Message here')
        }
        if (!errContent && content) {
            setErrContent(null)

            let data = {receiver_address: props?.otheruser?.user?.wallet_address, content:content}
            await jwtAxios.post(`/message`, data).then((response)=>{
                props.onHide();
                SetContent(null)
                dispatch(notificationSuccess("Message Sent successfully !"))
                // toast.success('Message Sent successfully !', {
                //     position: "bottom-right",
                //     autoClose: 3000,
                //     hideProgressBar: true,
                //     closeOnClick: true,
                //     pauseOnHover: true,
                //     draggable: true,
                //     progress: undefined,
                //     theme: "dark",
                // });
                window.location.href="/chat"
            })
        }
        
    }
    return (
        <Modal
            {...props}
            dialogClassName="login-modal"
            backdropClassName="login-modal-backdrop"
            aria-labelledby="contained-modal"
            backdrop="static"
            keyboard={false}
            centered
        >
            <Modal.Body>
                <div className="modal-heading">
                    <div className="profile-img">
                        <img src={props?.otheruser?.imageUrl ? props?.otheruser?.imageUrl :require('../content/images/escrows-5.png')} alt="Gabriel  Erickson" width="48" height="48" />
                    </div>
                    Message to {props?.otheruser?.user?.fname}  {props?.otheruser?.user?.lname}
                </div>
                <p>Start a conversation with {props?.otheruser?.user?.fname}  {props?.otheruser?.user?.lname}</p>
                <Form>
                    <Form.Group className="message-form">
                        <Form.Label>Message</Form.Label>
                        <Form.Control type="text" name="content" as="textarea" placeholder={`Start a conversation with ${props?.otheruser?.user?.fname} ${props?.otheruser?.user?.lname}`} value={content} onChange={onChangeMessage}/>
                        {errContent && <p className="error">{errContent}</p>}
                    </Form.Group>
                    <div className="form-action-group">
                        <Button variant="primary" onClick={onSubmit}>Send</Button>
                        <Button variant="secondary" onClick={props.onHide}>
                            Cancel
                        </Button>
                    </div>
                </Form>
            </Modal.Body>
        </Modal>
    );
};

export default MessageView;
