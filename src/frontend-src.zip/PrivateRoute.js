import React from "react";import { useSelector } from "react-redux";
 import { Navigate } from "react-router-dom";
import { userDetails } from "./store/slices/AuthSlice";


const ProtectedRoute = ({ children }) => {
    const userData = useSelector(userDetails);
  const authed = userData.authToken

  return authed ? children : <Navigate to={"/" }/> };

export default ProtectedRoute;