import React from "react";
import Profile from "./profile";

function ProfileComponent (props) {
  return (
    <>
      <Profile isLogin={props.isLogin} />
    </>
  );
}

export default ProfileComponent ;