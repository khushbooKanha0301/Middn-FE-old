import React from "react";
import AccountSetting from "../layout/accountSetting";

function AccountSettingComponent() {
  return (
    <>
      <AccountSetting />
    </>
  );
}

export default AccountSettingComponent;
