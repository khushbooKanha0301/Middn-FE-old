import React, { useState } from "react";
import { Col, Row, Button, Card, Form, Nav } from "react-bootstrap";
import { UploadIcon } from "../../component/SVGIcon";
import Select from 'react-select';
import CreateEscrowView from "./CreateEscrow";

const data = [
    {
        value: 1,
        text: 'Any',
        icon: <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="12" fill="#C4C4C4" />
        </svg>
    },
    {
        value: 2,
        text: 'BTC',
        icon: <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="12" fill="#C4C4C4" />
        </svg>
    },
    {
        value: 3,
        text: 'Anywhere',
        icon: <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="12" fill="#C4C4C4" />
        </svg>
    },
];
export const Escrow = () => {
    const [selectedOptionAny, setSelectedOptionAny] = useState(data[0]);
    const [selectedOptionBTC, setSelectedOptionBTC] = useState(data[1]);
    const [selectedOptionAnywhere, setSelectedOptionAnywhere] = useState(data[2]);
    const handleChangeAny = e => {
        setSelectedOptionAny(e);
    }
    const handleChangeBTC = e => {
        setSelectedOptionBTC(e);
    }
    const handleChangeAnywhere = e => {
        setSelectedOptionAnywhere(e);
    }
    const [createEscrowModalShow, setCreateEscrowModalShow] = useState(false);
    const createEscrowModalToggle = () => setCreateEscrowModalShow(!createEscrowModalShow);
    return (
        <div className="escrow-view">
            <h4>Hi Alex, Welcome back!</h4>
            <h1>Your Escrow</h1>
            <Row>
                <Col lg="8">
                    <div className="create-escrow">
                        <p>Create your escrow</p>
                        <Button variant="primary" onClick={createEscrowModalToggle} type="button">
                            <UploadIcon width="16" height="16" /> Create
                        </Button>
                    </div>
                </Col>
                <Col lg="4">
                    <Card className="cards-dark">
                        <Card.Body>
                            <Card.Title as="h2">Your Latest Ticket</Card.Title>
                            <Form.Group className="form-group">
                                <Form.Label>Description of Transaction</Form.Label>
                                <Form.Control type="text" placeholder="app.middn..9341982390" />
                            </Form.Group>
                            <div className="d-flex justify-content-between align-items-center expired">
                                <div>Expired</div>
                                <div>23:20 24/02/2022</div>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
            <div className="escrow-active-offers">
                <h2>Active offers</h2>
                <Row className="justify-content-between align-items-center">
                    <Col lg="auto">
                        <Nav defaultActiveKey="all" as="ul" className="filter-btn">
                            <Nav.Item as="li">
                                <Nav.Link eventKey="all">All</Nav.Link>
                            </Nav.Item>
                            <Nav.Item as="li">
                                <Nav.Link eventKey="buy">Buy</Nav.Link>
                            </Nav.Item>
                            <Nav.Item as="li">
                                <Nav.Link eventKey="sell">Sell</Nav.Link>
                            </Nav.Item>
                        </Nav>
                    </Col>
                    <Col lg="auto">
                        <Select
                            defaultValue={selectedOptionAny}
                            value={selectedOptionAny}
                            className="select-dropdown"
                            isSearchable={false}
                            components={{
                                IndicatorSeparator: () => null
                            }}
                            classNamePrefix="select-dropdown"
                            options={data}
                            onChange={handleChangeAny}
                            getOptionLabel={e => (
                                <div className="selected-dropdown">
                                    {e.icon}
                                    <span>{e.text}</span>
                                </div>
                            )}
                        />
                        <Select
                            defaultValue={selectedOptionBTC}
                            value={selectedOptionBTC}
                            isSearchable={false}
                            className="select-dropdown"
                            components={{
                                IndicatorSeparator: () => null
                            }}
                            classNamePrefix="select-dropdown"
                            options={data}
                            onChange={handleChangeBTC}
                            getOptionLabel={e => (
                                <div className="selected-dropdown">
                                    {e.icon}
                                    <span>{e.text}</span>
                                </div>
                            )}
                        />
                        <Select
                            defaultValue={selectedOptionAnywhere}
                            value={selectedOptionAnywhere}
                            isSearchable={false}
                            className="select-dropdown"
                            components={{
                                IndicatorSeparator: () => null
                            }}
                            classNamePrefix="select-dropdown"
                            options={data}
                            onChange={handleChangeAnywhere}
                            getOptionLabel={e => (
                                <div className="selected-dropdown">
                                    {e.icon}
                                    <span>{e.text}</span>
                                </div>
                            )}
                        />
                    </Col>
                </Row>
                <div className="table-responsive">
                    <div className="flex-table">
                        <div className="flex-table-header">
                            <div className="escrow-price">Price</div>
                            <div className="escrow-title">Title</div>
                            <div className="escrow-payment">Payment methods</div>
                            <div className="escrow-time">Time constraints</div>
                            <div className="escrow-trader">Trader</div>
                            <div className="escrow-actions">Actions</div>
                            <div className="escrow-network">Network</div>
                        </div>
                        <div className="flex-table-body">
                            <div className="escrow-price">
                                <h5>15.4 ETH</h5>
                                <p>Buy Limit 0.1-0.6 BTC</p>
                            </div>
                            <div className="escrow-title">
                                Cheap for you
                            </div>
                            <div className="text-center escrow-payment">
                                <img src={require('../../content/images/ethereum.png')} alt="Ethereum" className="me-2" />  Ethereum
                            </div>
                            <div className="text-center escrow-time">24 Hours</div>
                            <div className="text-center escrow-trader">
                                <div className="trader-profile">
                                    <div className="profile-image">
                                        <img src={require('../../content/images/escrows-5.png')} alt="Gabriel  Erickson" />
                                        <div className="profile-status"></div>
                                    </div>
                                    <div>
                                        <div className="trader-name">Gabriel</div>
                                        <label>(100%, 500+)</label>
                                    </div>
                                </div>
                            </div>
                            <div className="text-center escrow-actions"><Button variant="primary">Buy</Button></div>
                            <div className="escrow-network">Binance Smart Chain</div>
                        </div>
                        <div className="flex-table-body">
                            <div className="escrow-price">
                                <h5>15.4 ETH</h5>
                                <p>Buy Limit 0.1-0.6 BTC</p>
                            </div>
                            <div className="escrow-title">
                                Cheap for you
                            </div>
                            <div className="text-center escrow-payment">
                                <img src={require('../../content/images/ethereum.png')} alt="Ethereum" className="me-2" />  Ethereum
                            </div>
                            <div className="text-center escrow-time">24 Hours</div>
                            <div className="text-center escrow-trader">
                                <div className="trader-profile">
                                    {/* <div className="profile-image">
                                        <img src={require("../../content/images/escrows-5.png")} alt="Gabriel  Erickson" />
                                        <div className="profile-status"></div>
                                    </div> */}
                                    <div>
                                        <div className="trader-name">Gabriel</div>
                                        <label>(100%, 500+)</label>
                                    </div>
                                </div>
                            </div>
                            <div className="text-center escrow-actions"><Button variant="primary">Buy</Button></div>
                            <div className="escrow-network">Binance Smart Chain</div>
                        </div>
                        <div className="flex-table-body">
                            <div className="escrow-price">
                                <h5>15.4 ETH</h5>
                                <p>Buy Limit 0.1-0.6 BTC</p>
                            </div>
                            <div className="escrow-title">
                                Cheap for you
                            </div>
                            <div className="text-center escrow-payment">
                                <img src={require('../../content/images/ethereum.png')} alt="Ethereum" className="me-2" />  Ethereum
                            </div>
                            <div className="text-center escrow-time">24 Hours</div>
                            <div className="text-center escrow-trader">
                                <div className="trader-profile">
                                    <div className="profile-image">
                                        <img src={require('../../content/images/escrows-5.png')} alt="Gabriel  Erickson" />
                                        <div className="profile-status"></div>
                                    </div>
                                    <div>
                                        <div className="trader-name">Gabriel</div>
                                        <label>(100%, 500+)</label>
                                    </div>
                                </div>
                            </div>
                            <div className="text-center escrow-actions"><Button variant="primary">Buy</Button></div>
                            <div className="escrow-network">Binance Smart Chain</div>
                        </div>
                        <div className="flex-table-body">
                            <div className="escrow-price">
                                <h5>15.4 ETH</h5>
                                <p>Buy Limit 0.1-0.6 BTC</p>
                            </div>
                            <div className="escrow-title">
                                Cheap for you
                            </div>
                            <div className="text-center escrow-payment">
                                <img src={require('../../content/images/ethereum.png')} alt="Ethereum" className="me-2" />  Ethereum
                            </div>
                            <div className="text-center escrow-time">24 Hours</div>
                            <div className="text-center escrow-trader">
                                <div className="trader-profile">
                                    <div className="profile-image">
                                        <img src={require('../../content/images/escrows-5.png')} alt="Gabriel  Erickson" />
                                        <div className="profile-status"></div>
                                    </div>
                                    <div>
                                        <div className="trader-name">Gabriel</div>
                                        <label>(100%, 500+)</label>
                                    </div>
                                </div>
                            </div>
                            <div className="text-center escrow-actions"><Button variant="primary">Buy</Button></div>
                            <div className="escrow-network">Binance Smart Chain</div>
                        </div>
                        <div className="flex-table-body">
                            <div className="escrow-price">
                                <h5>15.4 ETH</h5>
                                <p>Buy Limit 0.1-0.6 BTC</p>
                            </div>
                            <div className="escrow-title">
                                Cheap for you
                            </div>
                            <div className="text-center escrow-payment">
                                <img src={require('../../content/images/ethereum.png')} alt="Ethereum" className="me-2" />  Ethereum
                            </div>
                            <div className="text-center escrow-time">24 Hours</div>
                            <div className="text-center escrow-trader">
                                <div className="trader-profile">
                                    <div className="profile-image">
                                        <img src={require('../../content/images/escrows-5.png')} alt="Gabriel  Erickson" />
                                        <div className="profile-status"></div>
                                    </div>
                                    <div>
                                        <div className="trader-name">Gabriel</div>
                                        <label>(100%, 500+)</label>
                                    </div>
                                </div>
                            </div>
                            <div className="text-center escrow-actions"><Button variant="primary">Buy</Button></div>
                            <div className="escrow-network">Binance Smart Chain</div>
                        </div>
                        <div className="flex-table-body">
                            <div className="escrow-price">
                                <h5>15.4 ETH</h5>
                                <p>Buy Limit 0.1-0.6 BTC</p>
                            </div>
                            <div className="escrow-title">
                                Cheap for you
                            </div>
                            <div className="text-center escrow-payment">
                                <img src={require('../../content/images/ethereum.png')} alt="Ethereum" className="me-2" />  Ethereum
                            </div>
                            <div className="text-center escrow-time">24 Hours</div>
                            <div className="text-center escrow-trader">
                                <div className="trader-profile">
                                    <div className="profile-image">
                                        <img src={require('../../content/images/escrows-5.png')} alt="Gabriel  Erickson" />
                                        <div className="profile-status"></div>
                                    </div>
                                    <div>
                                        <div className="trader-name">Gabriel</div>
                                        <label>(100%, 500+)</label>
                                    </div>
                                </div>
                            </div>
                            <div className="text-center escrow-actions"><Button variant="primary">Buy</Button></div>
                            <div className="escrow-network">Binance Smart Chain</div>
                        </div>
                        <div className="flex-table-body">
                            <div className="escrow-price">
                                <h5>15.4 ETH</h5>
                                <p>Buy Limit 0.1-0.6 BTC</p>
                            </div>
                            <div className="escrow-title">
                                Cheap for you
                            </div>
                            <div className="text-center escrow-payment">
                                <img src={require('../../content/images/ethereum.png')} alt="Ethereum" className="me-2" />  Ethereum
                            </div>
                            <div className="text-center escrow-time">24 Hours</div>
                            <div className="text-center escrow-trader">
                                <div className="trader-profile">
                                    <div className="profile-image">
                                        <img src={require('../../content/images/escrows-5.png')} alt="Gabriel  Erickson" />
                                        <div className="profile-status"></div>
                                    </div>
                                    <div>
                                        <div className="trader-name">Gabriel</div>
                                        <label>(100%, 500+)</label>
                                    </div>
                                </div>
                            </div>
                            <div className="text-center escrow-actions"><Button variant="primary">Buy</Button></div>
                            <div className="escrow-network">Binance Smart Chain</div>
                        </div>
                    </div>
                </div>
            </div>
            <CreateEscrowView show={createEscrowModalShow} onHide={() => setCreateEscrowModalShow(false)} />
        </div>
    );
}

export default Escrow;
