import React, { useState } from 'react';
import { Modal, Row, Col, Form, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

export const CreateEscrowView = (props) => {
    const [step, setStep] = useState(1);

    const handleNext = () => {
        setStep(step + 1);
    };
    const handleBack = () => {
        setStep(step - 1);
    };
    return (
        <Modal
            {...props}
            dialogClassName="login-modal"
            backdropClassName="login-modal-backdrop"
            aria-labelledby="contained-modal"
            backdrop="static"
            keyboard={false}
            centered
        >
            <Form>
                {step === 1 &&
                    <>
                        <Modal.Header>
                            <Modal.Title>Create escrow</Modal.Title>
                        </Modal.Header>
                        <Modal.Body className="pt-3">
                            <p className="mb-4">Define yourself, are you a buyer or a seller?</p>
                            <Row>
                                <Col md="6">
                                    <Form.Check
                                        className="yourself-option"
                                        label="Buyer"
                                        name="radiooption"
                                        type="radio"
                                        id="radiooption1"
                                    />
                                </Col>
                                <Col md="6">
                                    <Form.Check
                                        className="yourself-option"
                                        label="Seller"
                                        name="radiooption"
                                        type="radio"
                                        id="radiooption2"
                                    />
                                </Col>
                            </Row>
                            <div className="form-action-group">
                                <Button variant="primary" onClick={handleNext}>Continue</Button>
                                <Button variant="secondary" onClick={props.onHide}>
                                    Cancel
                                </Button>
                            </div>
                        </Modal.Body>
                    </>
                }
                {step === 2 &&
                    <>
                        <Modal.Header>
                            <Modal.Title>Im Seller</Modal.Title>
                        </Modal.Header>
                        <Modal.Body className="pt-3">
                            <p className="mb-4">Define how customers open your offers, choose fixed if you have a specific price or let them choose with flexible.</p>
                            <h5 className="mb-4">Fixe</h5>
                            <Row>
                                <Col md="6">
                                    <Form.Group className="form-group within-focus">
                                        <Form.Label>Price</Form.Label>
                                        <div className="d-flex align-items-center">
                                            <Form.Control type="text" placeholder="1" />
                                            <div className="currency-type"><span className="currency-flag"></span>USD</div>
                                        </div>
                                    </Form.Group>
                                </Col>
                            </Row>
                            <h5 className="mt-2 mb-4">Flexible</h5>
                            <Row className="gx-3">
                                <Col md="6">
                                    <Form.Group className="form-group within-focus">
                                        <Form.Label>min</Form.Label>
                                        <div className="d-flex align-items-center">
                                            <Form.Control type="text" placeholder="5" />
                                            <div className="currency-type"><span className="currency-flag"></span>USD</div>
                                        </div>
                                    </Form.Group>
                                </Col>
                                <Col md="6">
                                    <Form.Group className="form-group within-focus">
                                        <Form.Label>max</Form.Label>
                                        <div className="d-flex align-items-center">
                                            <Form.Control type="text" placeholder="1000" />
                                            <div className="currency-type"><span className="currency-flag"></span>USD</div>
                                        </div>
                                    </Form.Group>
                                </Col>
                            </Row>
                            <Form.Text>Example: 5 USD - 100 USD</Form.Text>
                            <div className="form-action-group">
                                <Button variant="primary" onClick={handleNext}>Continue</Button>
                                <Button variant="secondary" onClick={props.onHide}>
                                    Cancel
                                </Button>
                            </div>
                        </Modal.Body>
                    </>
                }
                {step === 3 &&
                    <>
                        <Modal.Header>
                            <Modal.Title>Detail</Modal.Title>
                        </Modal.Header>
                        <Modal.Body className="pt-2">
                            <p className="mb-4">Tell us what you are selling and the description that best characterizes the nature of that sale and provide the time you will take to provide it.</p>
                            <Row className="gx-3">
                                <Col md="6">
                                    <Form.Group className="form-group">
                                        <Form.Label>Category</Form.Label>
                                        <Form.Select aria-label="High-value items">
                                            <option>High-value items</option>
                                        </Form.Select>
                                    </Form.Group>
                                </Col>
                                <Col md="6">
                                    <Form.Group className="form-group">
                                        <Form.Label>Object</Form.Label>
                                        <Form.Select aria-label="Jewelery">
                                            <option>Jewelery</option>
                                        </Form.Select>
                                    </Form.Group>
                                </Col>
                            </Row>
                            <Form.Group className="form-group mt-2">
                                <Form.Label>Description of Transaction</Form.Label>
                                <Form.Control type="text" placeholder="Description of Transaction" />
                            </Form.Group>
                            <h5 className="my-4">Time constraints</h5>
                            <Form.Group className="form-group">
                                <Form.Label>Process time</Form.Label>
                                <Form.Select aria-label="24 Hours">
                                    <option>24 Hours</option>
                                </Form.Select>
                            </Form.Group>
                            <div className="form-action-group">
                                <Button variant="primary" onClick={handleNext}>Create</Button>
                                <Button variant="secondary" onClick={handleBack}>
                                    Back
                                </Button>
                            </div>
                        </Modal.Body>
                    </>
                }
                {step === 4 &&
                    <>
                        <Modal.Header>
                            <Modal.Title>Escrow has been created</Modal.Title>
                        </Modal.Header>
                        <Modal.Body className="pt-2">
                            <p className="mb-4">Your secure link has been created, share it with your buyer to start trading with the decentralized escrow.</p>
                            <Form.Group className="form-group">
                                <Form.Label>Your Escrow Link</Form.Label>
                                <Form.Control type="text" placeholder="app.middn.com/join-transaction/09289341982390" />
                            </Form.Group>
                            <div className="form-action-group">
                                <Button variant="primary">Copy link</Button>
                                <Button variant="secondary" as={Link} to="/">
                                    Back home
                                </Button>
                            </div>
                        </Modal.Body>
                    </>
                }
            </Form>
        </Modal>
    );
};

export default CreateEscrowView;
