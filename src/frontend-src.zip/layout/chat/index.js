import React, { useState, useEffect, useRef } from "react";
import { Row, Col, Card, Button, Form } from 'react-bootstrap';
import PerfectScrollbar from "react-perfect-scrollbar";
import { LinkSimpleIcon, SmileyIcon, TrashIcon } from "../../component/SVGIcon";
import apiConfig from '../../config/config'
import { useSelector } from "react-redux";
import { userDetails, userGetFullDetails } from '../../store/slices/AuthSlice';
import jwtAxios from "../../service/jwtAxios";
import axios from "axios";
import { Timestamp } from "../../utils";
import Picker from "emoji-picker-react";
import { IoIosCloseCircle } from 'react-icons/io';
import { BsFillImageFill, BsFiletypePdf, BsFiletypeDoc, BsFileEarmarkArrowDown, BsFileImage } from 'react-icons/bs';
import { MdAudiotrack } from 'react-icons/md';
import { ImVideoCamera } from 'react-icons/im';


export const Chat = () => {
    const [allusers, setAllUsers] = useState([]);
    const userData = useSelector(userDetails);
    const [userName, setUserName] = useState(null);
    const userDetailsAll = useSelector(userGetFullDetails);
    const [receiverData, setReceiverData] = useState(null);
    const [messages, setMessages] = useState([]);
    const [receiverProfile, setReceiverProfile] = useState();
    const [showSmily, setShowSmily] = useState(false);
    const [messageText, setMessageText] = useState("");
    const [messageFile, setMessageFile] = useState("");
    const [scrollEl, setScrollEl] = useState();
    const [selectedEmoji, setSelectedEmoji] = useState([]);
    const emojiPickerRef = useRef(null);

    const getAllUserDetails = async () => {
        if (userData.authToken) {
            await jwtAxios.get(`/users/allusers`).then((response) => {
                setAllUsers(response?.data?.UserData)
            });
        }
    }
    const smilyOpen = () => {
        setShowSmily(!showSmily);
    }
    const ref = useRef(null);
    const { onClickOutside } = <Picker />;

    const handleClickOutside = (event) => {
        if (emojiPickerRef.current && !emojiPickerRef.current.contains(event.target)) {
            setShowSmily(false);
        }
    };

    useEffect(() => {
        document.addEventListener('click', handleClickOutside, true);
        return () => {
            document.removeEventListener('click', handleClickOutside, true);
        };
    }, []);


    const getChatUser = async (user) => {
        setReceiverData(user.user);
        fetchMessages(userDetailsAll?.wallet_address, user?.user?.wallet_address)
        const fullname = user.user.fname + ' ' + user.user.lname
        setUserName(fullname)
        if (user?.user?.wallet_address && userData.authToken) {
            await jwtAxios.get(`/auth/getuser/${user?.user?.wallet_address}`).then((response) => {
                setReceiverProfile(response.data.docUrl);
            })
        } else {
            setReceiverProfile()
        }
    }
    const sendMessage = async (message) => {
        setMessageFile("")
        setMessageText("")
        console.log("DATA out", message);
        await jwtAxios.post(`/message`, message, {
            headers: {
                'Content-Type': "multipart/form-data",
            }
        });
        fetchMessages(message.sender_address, message.receiver_address);
        scrollBottom.scrollTop = scrollBottom.scrollHeight;
    }

    const fetchMessages = async (sender_address, receiver_address) => {
        const response = await jwtAxios.get(`/message/${receiver_address}`);
        setMessages(response.data.messages);
    }
    const handleTextChange = (event) => {
        setMessageText(event.target.value);
    }

    useEffect(() => {
        getAllUserDetails(require('../../content/images/avatar.png'))
    }, []);

    useEffect(() => {
        const interval = setInterval(async () => {
            if (userDetailsAll?.wallet_address && receiverData?.wallet_address) {
                const response = await axios.get(`${apiConfig.BASE_URL}message/${userDetailsAll?.wallet_address}/${receiverData?.wallet_address}`);
                setMessages(response.data.messages);
            }
        }, 3000);
        return () => clearInterval(interval);

    }, []);

    const fileInputRef = useRef(null);
    const handleButtonClick = async () => {
        fileInputRef.current.click();
    }
    const state = {
        fileSize: null
    };

    const handleFileSelection = async (event) => {
        const selectedFile = event.target.files[0];
        setMessageFile(selectedFile);
    }
    const formateSize = (selectedFile) => {
        const fileSizeInBytes = selectedFile;
        const fileSizeInKB = fileSizeInBytes / 1024;
        const fileSizeInGB = fileSizeInKB / 1024 / 1024;
        let fileSize = fileSizeInBytes + ' bytes';
        if (fileSizeInGB >= 1) {
            fileSize = fileSizeInGB.toFixed(2) + ' GB';
        } else if (fileSizeInKB >= 1) {
            fileSize = fileSizeInKB.toFixed(2) + ' KB';
        }
        return fileSize;
    }

    const fileIcon = (extension) => {
        let ext = extension.split('.').pop();
        if (ext === 'jpg' || ext === 'png' || ext === 'gif' || ext === 'jpg') {
            return <span className="imageicon"><BsFillImageFill style={{ fontSize: '20px' }} /></span>;
        } else if (ext === 'pdf') {
            return <span className="imageicon"><BsFiletypePdf style={{ fontSize: '20px' }} /></span>;
        } else if (ext === 'doc' || ext === 'docx' || ext === 'dot' || ext === 'docm' || ext === 'doc' || ext === "odt") {
            return <span className="imageicon"><BsFiletypeDoc style={{ fontSize: '20px' }} /></span>;
        } else if (ext === 'mp3') {
            return <span className="imageicon"><MdAudiotrack style={{ fontSize: '20px' }} /></span>;
        } else if (ext === 'mp4') {
            return <span className="imageicon"><ImVideoCamera style={{ fontSize: '20px' }} /></span>;
        } else {
            return <span className="imageicon"><BsFileEarmarkArrowDown style={{ fontSize: '20px' }} /></span>;
        }

    }

    const handleDeselctImage = () => {
        setMessageFile("")
    }
    const getSubstringAfter = (string, substring) => {
        const index = string.indexOf(substring);
        if (index === -1) {
            return '';
        } else {
            return string.substring(index + substring.length);
        }
    }



    const onEmojiClick = (emojiData, event) => {
        const emoji = emojiData.emoji;
        setMessageText(`${messageText}${emoji}`);
        const selectedIndex = selectedEmoji.indexOf(emoji);
        if (selectedIndex === -1) {
            setSelectedEmoji([...selectedEmoji, emoji]);
        } else {
            const updatedSelectedEmojis = [...selectedEmoji];
            updatedSelectedEmojis.splice(selectedIndex, 1);
            setSelectedEmoji(updatedSelectedEmojis);
        }
    }

    const handleInputKeyPress = (event) => {
        if (event.key === "Enter") {
            const input = event.target;
            const newText = input.value.trim();
            if (newText !== "") {
                const selectedEmojisText = selectedEmoji.join("");
                const updatedText = `${messageText} ${selectedEmojisText} ${newText}`;
                setSelectedEmoji([]);
                input.value = updatedText.trim();
            }
        }
    }

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (ref.current && !ref.current.contains(event.target)) {
                onClickOutside && onClickOutside();
            }
        };
        document.addEventListener('click', handleClickOutside, true);
        return () => {
            document.removeEventListener('click', handleClickOutside, true);
        };
    }, [onClickOutside]);

    const darkTheme = {
        backgroundColor: '#222',
        emojiColor: '#fff',
        tabColor: '#fff',
        activeTabBackgroundColor: '#555',
        inputColor: '#fff',
        placeholderColor: '#aaa',
        searchIconColor: '#fff',
        inputBackgroundColor: '#444',
        emojiBackgroundColor: '#333',
        activeEmojiBackgroundColor: '#555',
        activeEmojiCheckmarkColor: '#fff',
    };

    var scrollBottom = document.getElementById("scrollBottom");
    if (scrollBottom) {
        scrollBottom.scrollTop = scrollBottom.scrollHeight;
    }

    return (
        <div className="chat-view">
            <Row>
                <Col lg="4">
                    <Card className="cards-dark">
                        <Card.Body>
                            <Card.Title as="h2">Messages</Card.Title>
                            <ul className="chat-list">
                                <PerfectScrollbar containerRef={ref => {
                                    setScrollEl(ref);
                                }} options={{ suppressScrollX: true }}>
                                    {allusers && allusers.map(user => (

                                        <>
                                            <li className={`mt-2 chat-box-list ${user ? "active" : ""}`} onClick={() => getChatUser(user)} sx={{ padding: { md: 4, xs: 2 } }}>
                                                <div className="chat-image">
                                                    <img src={user?.imageUrl ? user?.imageUrl : require('../../content/images/avatar.png')} alt={user?.user?.fname} />
                                                    <div className="chat-status"></div>
                                                </div>
                                                <div>
                                                    <div className="chat-name">{user?.user?.fname ? user?.user?.fname : null} {user?.user.lname ? user?.user?.lname : null}</div>
                                                </div>
                                            </li>
                                        </>
                                    ))}
                                    {!allusers &&
                                        <>
                                            <p className="text-center text-white">No Messages Yet...</p>
                                        </>
                                    }
                                </PerfectScrollbar>
                            </ul>
                            <Button variant="link">
                                <span className="load-arrow"></span>{" "}
                                <span className="menu-hide">Load more</span>
                            </Button>
                        </Card.Body>
                    </Card>
                </Col>
                <Col lg="8">
                    <Card className="cards-dark chat-box">
                        <Card.Body>
                            <Card.Title as="h2">Chatbox<p className="text-white">{userName}</p></Card.Title>
                            <div className="chat-box-list">
                                <ul>
                                    <PerfectScrollbar id="scrollBottom" options={{ suppressScrollX: true }} >
                                        {messages && messages.map((message) => (

                                            <>
                                                <li>
                                                    {(message?.messages?.sender_address !== userDetailsAll?.wallet_address) &&
                                                        <>
                                                            <div className="chat-image">
                                                                <img src={receiverProfile ? receiverProfile : require('../../content/images/avatar.png')} alt="Gabriel  Erickson" />
                                                            </div>
                                                            <div>
                                                                <div className="name">{userName} <span>{Timestamp(message?.messages?.created_at)}</span></div>
                                                                {message?.messages?.content !== "" && <><div className="chat-comment"> {message?.messages?.content}</div><br /><br /></>}
                                                                {message?.fileUrl && message?.fileUrl != "" &&
                                                                    <div class="chat-comment"><a href={message?.fileUrl} download><div>
                                                                        {fileIcon(message?.messages?.file)}
                                                                        <span>{getSubstringAfter(message?.messages?.file, "_")}</span>
                                                                    </div></a></div>
                                                                }
                                                            </div>

                                                        </>
                                                    }
                                                </li>

                                                <li>
                                                    {(message?.messages?.sender_address === userDetailsAll?.wallet_address) &&
                                                        <>
                                                            <div className="name">You <span>{Timestamp(message?.messages?.created_at)}</span></div>

                                                            {message?.messages?.content !== "" && <><div className="chat-comment"> {message?.messages?.content}</div><br /><br /></>}
                                                            {message?.fileUrl && message?.fileUrl != "" &&
                                                                <div class="chat-comment"><a href={message?.fileUrl} download><div>
                                                                    {fileIcon(message?.messages?.file)}
                                                                    <span>{getSubstringAfter(message?.messages?.file, "_")}</span>
                                                                </div></a></div>
                                                            }
                                                        </>
                                                    }
                                                </li>
                                            </>
                                        ))}
                                        {!messages &&
                                            <>
                                                <p className="text-center text-white">No Messages Yet...</p>
                                            </>
                                        }
                                    </PerfectScrollbar>
                                </ul>

                                {showSmily &&
                                    <div ref={emojiPickerRef} style={{ position: 'absolute', bottom: '110px' }}>
                                        <Picker
                                            onEmojiClick={onEmojiClick}
                                            autoFocusSearch={true}
                                            height={300} width={260}
                                            className="emoji-popup"
                                            theme='dark'
                                            lazyLoadEmojis={true}

                                        />
                                    </div>
                                }
                                <div className="chat-action">
                                    {messageFile &&
                                        <div className="attach">
                                            <div className="flex items-center justify-between px-2 py-1  border rounded-full shadow-md fileClass">

                                                <div className="flex items-center space-x-2">
                                                    {fileIcon(messageFile.name)}
                                                    <span className=" truncate">{messageFile.name}</span>
                                                    <IoIosCloseCircle style={{ fontSize: '25px', marginLeft: "14px" }} onClick={handleDeselctImage} />
                                                    <div className="file-size">
                                                        {messageFile?.size && formateSize(messageFile?.size)}
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    }
                                    <div className="messsge">
                                        <div className="button-container">
                                            <Button variant="link" onClick={() => smilyOpen()} ><SmileyIcon width="20" height="20" /></Button>
                                            <Button variant="link" className="ms-3" onClick={handleButtonClick}><LinkSimpleIcon width="20" height="20" /></Button>
                                            {/* <input
                                                ref={fileInputRef}
                                                type="file"
                                                accept=".jpg,.jpeg,.png,.pdf"
                                                onChange={handleFileSelection}
                                                style={{ display: "none" }}
                                            /> */}
                                        </div>

                                        <Form className="input-container"
                                            onSubmit={(e) => {
                                                e.preventDefault();
                                                let message = {
                                                    receiver_address: receiverData?.wallet_address,
                                                    content: e.target.elements.content.value,
                                                    file: messageFile ? messageFile : null
                                                };
                                                sendMessage(message);
                                                e.target.elements.content.value = '';
                                            }}>
                                            <input
                                                ref={fileInputRef}
                                                type="file"
                                                accept=".jpg,.jpeg,.png"
                                                onChange={handleFileSelection}
                                                style={{ display: "none" }}
                                            />

                                            <input type="text" className="form-control" placeholder={"Send a message…"} name="content" value={messageText} onChange={handleTextChange} onKeyPress={handleInputKeyPress} />

                                            <Button variant="primary" type="submit" size="sm">
                                                Send
                                            </Button>
                                        </Form>
                                    </div>
                                </div>

                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </div >
    );
}

export default Chat;
