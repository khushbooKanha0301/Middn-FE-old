import React from "react";
import HelpCenter from "./helpCenter";

function HelpCenterComponent() {
  return (
    <>
      <HelpCenter />
    </>
  );
}

export default HelpCenterComponent;
