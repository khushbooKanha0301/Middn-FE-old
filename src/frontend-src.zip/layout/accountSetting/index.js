import React, { useState, useEffect } from "react";
import { Row, Col, Card, Form, Button } from 'react-bootstrap';
import { CheckmarkIcon, IdentificationCardIcon, MapPinIcon, SecurityIcon, UserFocusIcon, UserListIcon } from '../../component/SVGIcon'
import ReactFlagsSelect from "react-flags-select";
import ChangePasswordView from "../../component/ChangePassword";
import apiConfig from '../../config/config'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useDispatch, useSelector } from "react-redux";
import { userDetails, userGetFullDetails } from '../../store/slices/AuthSlice';
import jwtAxios from "../../service/jwtAxios";
import { notificationSuccess } from "../../store/slices/notificationSlice";

export const AccountSetting = () => {
	const dispatch = useDispatch();
	const [country, setCountry] = useState(null);
	const [currency, setCurrency] = useState(null);
	const [modalShow, setModalShow] = useState(false);
	const modalToggle = () => setModalShow(!modalShow);
	const [fname, setFname] = useState(null);
	const [lname, setLname] = useState(null);
	const [phone, setPhone] = useState(null);
	const [email, setEmail] = useState(null);
	const [errEmail, setErrEmail] = useState(null);
	const [errPhone, setErrPhone] = useState(null);
	const [errFname, setErrFname] = useState(null);
	const [errLname, setErrLname] = useState(null);
	const [location, setLocation] = useState(null);
	const [currentPre, setCurrentPre] = useState(null);
	const [countryCode, setCountryCode] = useState("");
	const [countryCallingCode, setCountryCallingCode] = useState(null);
	const [countryShortName, setCountryShortName] = useState(null);
	const userData = useSelector(userDetails);
	const userDetailsAll = useSelector(userGetFullDetails);
	const countryDetails = useSelector((state) => state.auth.countryDetails)

	const flagUrl = countryCode ? `https://flagcdn.com/h40/${countryCode?.toLowerCase()}.png` : ""

	useEffect(() => {
		if (countryDetails) {
			setCountry(countryDetails?.country_name);
			setCountryCode(countryDetails?.country_code);
			setCountryCallingCode(countryDetails?.country_calling_code);
			setCountryShortName(countryDetails?.country_code)
		}
	}, [countryDetails]);

	useEffect(() => {
		if (userDetailsAll) {
			let user = userDetailsAll

			setFname(user?.fname ? user?.fname : null);

			setLname(user?.lname ? user?.lname : null);
			setPhone(user?.phone ? user?.phone : null);
			setEmail(user?.email ? user?.email : null);
			setLocation(country ? country : null);
			setCurrentPre(user?.currentpre ? user?.currentpre : null);
		}
	}, [userDetailsAll]);



	const submitHandler = async () => {
		if (!fname) {
			setErrFname('Please Enter First name')
		}
		if (!lname) {
			setErrLname('Please Enter Last name')
		}
		if (!phone) {
			setErrPhone('Please Enter phone number')
		}
		if (!email) {
			setErrEmail('Please Enter email')
		}
		if (!errEmail && !errPhone && !errFname && !errLname && phone && email && fname && lname) {
			setErrFname(null)
			setErrLname(null)
			setErrPhone(null)
			setErrEmail(null)
			let formSubmit = {
				fname: fname,
				lname: lname,
				email: email,
				phone: phone,
				location: country,
				currentpre: currentPre,
			}
			let updateUser = await jwtAxios
				.put(`/users`, formSubmit, {
					headers: {
						'Content-Type': "multipart/form-data",
					}
				})
			if (updateUser) {
				dispatch(notificationSuccess("User profile update successfully !"))

				// toast.success('user profile update successfully !', {
				// 	position: "bottom-right",
				// 	autoClose: 3000,
				// 	hideProgressBar: true,
				// 	closeOnClick: true,
				// 	pauseOnHover: true,
				// 	draggable: true,
				// 	progress: undefined,
				// 	theme: "dark",
				// });
			}
		}

	};
	const onChange = (e) => {
		if (e.target.name == 'fname') {
			if (!e.target.value) {
				setErrFname('Please Enter First name');
			} else {
				setErrFname(null);
			}
			setFname(e.target.value)
		} else if (e.target.name == 'lname') {
			if (!e.target.value) {
				setErrLname('Please Enter Last name');
			} else {
				setErrLname(null);
			}
			setLname(e.target.value)
		} else if (e.target.name == 'phone') {
			setPhone(e.target.value)
		} else if (e.target.name == 'email') {
			if (!e.target.value) {
				setErrEmail('Please Enter Email');
			} else {
				setErrEmail(null);
			}
			setEmail(e.target.value)
		} else if (e.target.name == 'location') {
			setLocation(e.target.value)
		} else if (e.target.name == 'currentPre') {
			setCurrentPre(e.target.value)
		}
	};
	return (
		<div className="account-setting">
			<h1>Account Setting</h1>
			<Row>
				<Col lg="8">
					<Card className="cards-dark mb-32">
						<Card.Body>
							<Card.Title as="h2">Account Information</Card.Title>
							<Form>
								<Row>
									<Col md="6">
										<Form.Group className="form-group">
											<Form.Label>First name (required)</Form.Label>
											<Form.Control type="text" placeholder="first name" name='fname' value={fname} onChange={(e) => onChange(e)} />
											{errFname && <p className="error">{errFname}</p>}
										</Form.Group>
									</Col>
									<Col md="6">
										<Form.Group className="form-group">
											<Form.Label>Last name (required)</Form.Label>
											<Form.Control type="text" placeholder="last name" name='lname' value={lname} onChange={(e) => onChange(e)} />
											{errLname && <p className="error">{errLname}</p>}
										</Form.Group>
									</Col>
								</Row>
								<Row>
									<Col md="6">
										<Form.Group className="form-group">
											<Form.Label>Email (required)</Form.Label>
											<Form.Control type="email" placeholder="email" name='email' value={email} onChange={(e) => onChange(e)} />
											{errEmail && <p className="error">{errEmail}</p>}

										</Form.Group>
									</Col>
									<Col md="6">
										<Form.Group className="form-group">
											<Form.Label>Phone number (required)</Form.Label>
											<div className="d-flex align-items-center">
												<Form.Control type="tel" placeholder={countryCallingCode} name='phone' value={phone} onChange={(e) => onChange(e)} />
												{flagUrl ? <img src={flagUrl} alt="Flag" style={{ weight: "30px", height: "30px" }} className="circle-data" /> : 'No Flag'}
												<p className="text-white mb-0">{countryShortName}</p>
											</div>
											{errPhone && <p className="error">{errPhone}</p>}
										</Form.Group>
									</Col>
								</Row>
								<Row>
									<Col md="6">
										<Form.Group className="form-group">
											<Form.Label>Location</Form.Label>
											<div className="d-flex align-items-center">
												<Form.Control type="text" placeholder={country} readOnly name='location' value={country} onChange={(e) => onChange(e)} />
												{flagUrl ? <img src={flagUrl} alt="Flag" style={{ weight: "30px", height: "30px" }} className="circle-data" /> : 'No Flag'}
												<p className="text-white mb-0">{countryShortName}</p>
											</div>
										</Form.Group>
									</Col>
									<Col md="6">
										<Form.Group className="form-group">
											<Form.Label>Currency preferred </Form.Label>
											<div className="d-flex align-items-center">
												<Form.Control type="text" placeholder={currency} name='currentPre' value={currentPre} onChange={onChange} />
												{flagUrl ? <img src={flagUrl} alt="Flag" style={{ weight: "30px", height: "30px" }} className="circle-data" /> : 'No Flag'}
												<p className="text-white mb-0">{countryShortName}</p>
											</div>
										</Form.Group>
									</Col>
								</Row>
								<Row>
									<div className="edit-btn ">
										<Button className="btn btn-success" variant="success" onClick={submitHandler} >Save</Button>
									</div>
								</Row>
							</Form>

							<Card.Title as="h2" className="mb-3 mt-2">Security</Card.Title>
							<div className="security-details">
								<div className="security-text">
									<div className="security-code"><SecurityIcon width="20" height="16" /></div>
									<h4>Password</h4>
									<p>Login password is used to log in to your account.</p>
								</div>
								<Button variant="primary" onClick={modalToggle}>Reset Password</Button>
							</div>
						</Card.Body>
					</Card>
					<Card className="cards-dark mb-4">
						<Card.Body>
							<Card.Title as="h2">2FA</Card.Title>
							<ul className="two-fa">
								<li>
									<div className="two-fa-step">
										<img
											src={require('../../content/images/google-authenticator.png')}
											alt="Google Authentication"
										/>
										<h4>Google Authentication</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
									</div>
									<Button variant="primary">Active</Button>
								</li>
								<li>
									<div className="two-fa-step">
										<img
											src={require('../../content/images/mobile-device.png')}
											alt="SMS Authentication"
										/>
										<h4>SMS Authentication</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
									</div>
									<Button variant="primary">Active</Button>
								</li>
								<li>
									<div className="two-fa-step">
										<img
											src={require('../../content/images/mobile-device.png')}
											alt="Google Authentication"
										/>
										<h4>Email Authentication</h4>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
									</div>
									<Button variant="light" disabled>Nonactive</Button>
								</li>
							</ul>
						</Card.Body>
					</Card>
				</Col>
				<Col lg="4">
					<Card className="cards-dark">
						<Card.Body>
							<Card.Title as="h2">Verified</Card.Title>
							<ul className="verified">
								<li>
									<div className="verified-step">
										<UserListIcon width="25" height="24" />
										<p>Personal information</p>
									</div>
									<div className="checkmark">
										<CheckmarkIcon width="10" height="8" />
									</div>
								</li>
								<li>
									<div className="verified-step">
										<IdentificationCardIcon width="24" height="24" />
										<p>Goverment-issued ID</p>
									</div>
									<div className="checkmark">
										<CheckmarkIcon width="10" height="8" />
									</div>
								</li>
								<li>
									<div className="verified-step">
										<UserFocusIcon width="24" height="24" />
										<p>Facial recognition</p>
									</div>
									<div className="checkmark">
										<CheckmarkIcon width="10" height="8" />
									</div>
								</li>
								<li>
									<div className="verified-step">
										<MapPinIcon width="24" height="24" />
										<p>Proof Location</p>
									</div>
									<div className="checkmark">
										<CheckmarkIcon width="10" height="8" />
									</div>
								</li>
							</ul>
						</Card.Body>
					</Card>
				</Col>
			</Row>
			<ChangePasswordView show={modalShow} onHide={() => setModalShow(false)} />
		</div>
	);
}
export default AccountSetting;
