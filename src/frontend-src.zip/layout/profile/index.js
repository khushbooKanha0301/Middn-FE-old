import React, { useState , useEffect} from "react";
import { Col, Row, Card, Button, Tabs, Tab, Nav, Form } from 'react-bootstrap';
import EditProfileView from "../../component/EditProfile";
import MessageView from '../../component/Message';
import ReportUserView from "../../component/ReportUser";
import { StarRating } from '../../component/StarRating';
import { InstagramIcon, TelegramIcon, MessageIcon, SimpleCheckIcon, TwitterIcon, StarFillIcon, StarEmptyIcon } from '../../component/SVGIcon';
import { useSelector } from "react-redux";
import { userDetails, userGetFullDetails } from '../../store/slices/AuthSlice';
import apiConfig from '../../config/config'


export const Profile = (props) => {
    const [modalShow, setModalShow] = useState(false);
    const modalToggle = () => setModalShow(!modalShow);
    const [reportModalShow, setReportModalShow] = useState(false);
    const reportModalToggle = () => setReportModalShow(!reportModalShow);
    const [editProfileModalShow, setEditProfileModalShow] = useState(false);
    const editProfileModalToggle = () => setEditProfileModalShow(!editProfileModalShow);
    const userData = useSelector(userDetails);
    const userDetailsAll = useSelector(userGetFullDetails);
    return (
        <div className="profile-view">
            <Row>
                <Col lg="8">
                    <div className="profile-details">
                        <Row className="g-0">
                            <Col xs="2">
                                <Button variant="link" className="profile-image" onClick={editProfileModalToggle}>
                                    <img src={require('../../content/images/avatar.png')} alt={"Avatar"} />
                                    <div className="profile-status"></div>
                                </Button>
                            </Col>
                            <Col>
                                <h1>TEst <span className="verify-status"><SimpleCheckIcon width="16" height="12" /></span></h1>
                                <div className="about-profile">
                                    <h6><strong>526</strong> transactions</h6>
                                    <h6 className="feedback"><strong>15</strong> positive feedback</h6>
                                </div>
                                <p>Crypto trader with more than 6 years of experience.</p>
                                <div className="profile-btn">
                                    <Button variant="primary" onClick={modalToggle} ><MessageIcon width="18" height="16" />Message </Button>
                                    <Button variant="danger" className="buttonspace" onClick={reportModalToggle}>ReportUser</Button>
                                </div>
                                <p>Social media</p>
                                <div className="social-btn">
                                    <Button variant="link"><InstagramIcon width="32" height="32" /></Button>
                                    <Button variant="link"><TwitterIcon width="32" height="32" /></Button>
                                    <Button variant="link"><TelegramIcon width="32" height="32" /></Button>
                                </div>
                            </Col>
                        </Row>
                    </div>
                </Col>
                <Col lg="4">
                    <Card className="cards-dark">
                        <Card.Body>
                            <Card.Title as="h2">Information</Card.Title>
                            <div className="profile-information">
                                <Row className="align-items-center g-0">
                                    <Col xs="7"><label>Location</label></Col>
                                    <Col><img src={require('../../content/images/us-flag.png')} alt="United States" width="14" height="10" /> United States</Col>
                                </Row>
                                <Row className="align-items-center g-0">
                                    <Col xs="7"><label>Trades</label></Col>
                                    <Col>1029</Col>
                                </Row>
                                <Row className="align-items-center g-0">
                                    <Col xs="7"><label>Trading partners</label></Col>
                                    <Col>720</Col>
                                </Row>
                                <Row className="align-items-center g-0">
                                    <Col xs="7"><label>Feedback score</label></Col>
                                    <Col>99%</Col>
                                </Row>
                                <Row className="align-items-center g-0">
                                    <Col xs="7"><label>Account created</label></Col>
                                    <Col>8 months ago</Col>
                                </Row>
                                <Row className="align-items-center g-0">
                                    <Col xs="7"><label>Typical finalization time</label></Col>
                                    <Col>20 minutes</Col>
                                </Row>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
            <Tabs defaultActiveKey="active-offers" id="profile-tab">
                <Tab eventKey="active-offers" title="Active offers">
                    <h2>Active offers</h2>
                    <Nav defaultActiveKey="all" as="ul" className="filter-btn">
                        <Nav.Item as="li">
                            <Nav.Link eventKey="all">All</Nav.Link>
                        </Nav.Item>
                        <Nav.Item as="li">
                            <Nav.Link eventKey="buy">Buy</Nav.Link>
                        </Nav.Item>
                        <Nav.Item as="li">
                            <Nav.Link eventKey="sell">Sell</Nav.Link>
                        </Nav.Item>
                    </Nav>
                    <div className="table-responsive">
                        <div className="flex-table">
                            <div className="flex-table-header">
                                <div className="price">Price</div>
                                <div className="payment">Payment methods</div>
                                <div className="time">Time constraints</div>
                                <div className="trader">Trader</div>
                                <div className="actions">Actions</div>
                            </div>
                            <div className="flex-table-body">
                                <div className="price">
                                    <h5>Flexible</h5>
                                    <p>Buy Limit 100-2500 USD</p>
                                </div>
                                <div className="text-center payment">
                                    <span className="circle-dote"></span>MID
                                </div>
                                <div className="text-center time">24 HOURS</div>
                                <div className="text-center trader">
                                    <div className="trader-profile">
                                        <div className="profile-image">
                                            <img src={require('../../content/images/escrows-5.png')} alt="Gabriel  Erickson" />
                                            <div className="profile-status"></div>
                                        </div>
                                        <div>
                                            <div className="trader-name">Gabriel</div>
                                            <label>(100%, 500+)</label>
                                        </div>
                                    </div>
                                </div>
                                <div className="text-center actions"><Button variant="primary">Buy</Button></div>
                            </div>
                            <div className="flex-table-body">
                                <div className="price">
                                    <h5>1250.00 USD</h5>
                                    <p>Buy Limit 1250.00 USD</p>
                                </div>
                                <div className="text-center payment">
                                    <span className="circle-dote"></span>MID
                                </div>
                                <div className="text-center time">2 DAYS</div>
                                <div className="text-center trader">
                                    <div className="trader-profile">
                                        <div className="profile-image">
                                            <img src={require('../../content/images/escrows-5.png')} alt="Gabriel  Erickson" />
                                            <div className="profile-status"></div>
                                        </div>
                                        <div>
                                            <div className="trader-name">Gabriel</div>
                                            <label>(100%, 500+)</label>
                                        </div>
                                    </div>
                                </div>
                                <div className="text-center actions"><Button variant="primary">Buy</Button></div>
                            </div>
                        </div>
                    </div>
                </Tab>
                <Tab eventKey="reviews" title="Reviews">
                    <div className="d-flex justify-content-between align-items-center">
                        <h2>Reviews</h2>
                        <Form.Select aria-label="Newest">
                            <option>Newest</option>
                            <option value="1">Standard</option>
                            <option value="2">Latter</option>
                        </Form.Select>
                    </div>
                    <div className="reviews-list">
                        <Card className="cards-dark">
                        <Card.Body>
                            <div className="reviewer-image">
                            <img src={require('../../content/images/escrows-5.png')} alt="Gabriel  Erickson" width="51" height="51" />
                            </div>
                            <div className="reviewer-details">
                                <StarRating ratings={5} customIcon={<StarFillIcon width="12" height="12" />} customEmptyIcon={<StarEmptyIcon width="12" height="12" />} />
                                <div className="reviewer-name">Gabriel <span>12 hours ago</span></div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                <div className="reviewer-transaction">Transaction : <strong>Buy 5 BTC</strong></div>
                            </div>
                        </Card.Body>
                        </Card>
                        <Card className="cards-dark">
                        <Card.Body>
                            <div className="reviewer-image">
                            <img src={require('../../content/images/escrows-5.png')} alt="Gabriel  Erickson" width="51" height="51" />
                            </div>
                            <div className="reviewer-details">
                                <StarRating ratings={5} customIcon={<StarFillIcon width="12" height="12" />} customEmptyIcon={<StarEmptyIcon width="12" height="12" />} />
                                <div className="reviewer-name">Gabriel <span>12 hours ago</span></div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                <div className="reviewer-transaction">Transaction : <strong>Buy 5 BTC</strong></div>
                            </div>
                        </Card.Body>
                        </Card>
                        <Card className="cards-dark">
                        <Card.Body>
                            <div className="reviewer-image">
                            <img src={require('../../content/images/escrows-5.png')} alt="Gabriel  Erickson" width="51" height="51" />
                            </div>
                            <div className="reviewer-details">
                                <StarRating ratings={5} customIcon={<StarFillIcon width="12" height="12" />} customEmptyIcon={<StarEmptyIcon width="12" height="12" />} />
                                <div className="reviewer-name">Gabriel <span>12 hours ago</span></div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                <div className="reviewer-transaction">Transaction : <strong>Buy 5 BTC</strong></div>
                            </div>
                        </Card.Body>
                        </Card>
                        <Card className="cards-dark">
                        <Card.Body>
                            <div className="reviewer-image">
                            <img src={require('../../content/images/escrows-5.png')} alt="Gabriel  Erickson" width="51" height="51" />
                            </div>
                            <div className="reviewer-details">
                                <StarRating ratings={5} customIcon={<StarFillIcon width="12" height="12" />} customEmptyIcon={<StarEmptyIcon width="12" height="12" />} />
                                <div className="reviewer-name">Gabriel <span>12 hours ago</span></div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                <div className="reviewer-transaction">Transaction : <strong>Buy 5 BTC</strong></div>
                            </div>
                        </Card.Body>
                        </Card>
                    </div>
                </Tab>
            </Tabs>
            <MessageView show={modalShow} onHide={() => setModalShow(false)} />
            <ReportUserView show={reportModalShow} onHide={() => setReportModalShow(false)} />
            <EditProfileView show={editProfileModalShow} onHide={() => setEditProfileModalShow(false)} />
        </div>
    );
}

export default Profile;
