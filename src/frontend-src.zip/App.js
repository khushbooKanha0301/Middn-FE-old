import React, { useEffect, useState } from 'react'
import { Container, Spinner } from 'react-bootstrap'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'

import Sidebar from './component/Sidebar'
import Header from './component/Header'
import LoginView from './component/Login'
import HomePageComponent from './layout/homePageComponent'
import AccountSettingComponent from './layout/AccountSettingComponent'
import NotificationComponent from './layout/NotificationComponent'
import TraderProfileComponent from './layout/TraderProfileComponent'
import ProfileComponent from './layout/ProfileComponent'
import ChatComponent from './layout/ChatComponent'
import EscrowComponent from './layout/EscrowComponent'
import TradeHistoryComponent from './layout/TradeHistoryComponent'
import HelpCenterComponent from './layout/HelpCenterComponent'
import ProtectedRoute from './PrivateRoute'
import { useDispatch, useSelector } from 'react-redux'
import { getCountryDetails, getCountryName, userDetails, userGetData } from './store/slices/AuthSlice'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export const App = () => {
  const dispatch = useDispatch()
  const [isOpen, setIsOpen] = useState(true)
  const sidebarToggle = () => setIsOpen(!isOpen)
  const [modalShow, setModalShow] = useState(false)
  const modalToggle = () => setModalShow(!modalShow)
  const [isSign, setIsSign] = useState(null)
  const [isLogin, setisLogin] = useState(false)
  const acAddress = useSelector(userDetails)
  const authState = useSelector((state) => state.commonReducer)
  const notification = useSelector((state) => state.notificationReducer)


  const handleAccountAddress = (address) => {
    setIsSign(false)
    setisLogin(true)
  }

  const signOut = () => {
    setIsSign(true)
  }

  useEffect(() => {
    if (acAddress.userid) {
      dispatch(userGetData(acAddress.userid)).unwrap()
      dispatch(getCountryDetails())
    }
  }, [acAddress.userid])
  
  useEffect(() => {
    if (notification?.status) {
      toast.success(notification.message, {
        position: "bottom-right",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
    });
    }
  }, [notification])

  return (
    <>
      <Container fluid="xxl" className={`${isOpen ? 'open-sidebar' : ''}`}>
        <Sidebar clickHandler={sidebarToggle} />
        <div className="wrapper">
          <Header
            clickHandler={sidebarToggle}
            clickModalHandler={modalToggle}
            signOut={signOut}
          />
          {authState?.loading && (
            <div
              style={{
                background: '#6d686887',
                zIndex: 99999,
                display: 'flex',
                position: 'fixed',
                alignItems: 'center',
                justifyContent: 'center',
                width: '100%',
                height: '100vh',
                top: 0,
                left: 0,
              }}
            >
              <Spinner
                as="span"
                variant="light"
               
                role="status"
                aria-hidden="true"
                animation="border"
              />
            </div>
          )}

          <div className="contain">
            <Routes>
              <Route path="/" element={<HomePageComponent />} />
              <Route
                path="/settings"
                element={
                  <ProtectedRoute>
                    <AccountSettingComponent />
                  </ProtectedRoute>
                }
              />
              <Route path="/notification" element={<NotificationComponent />} />
              <Route
                path="/profile/:address"
                element={<TraderProfileComponent isLogin={isLogin} />}
              />
              {/* <Route
								path="/profile"
								element={
									<ProfileComponent isLogin={isLogin}/>
								}
							/> */}
              <Route
                path="/chat"
                element={
                  <ProtectedRoute>
                    <ChatComponent />
                  </ProtectedRoute>
                }
              />
              <Route path="/escrow" element={<EscrowComponent />} />
              <Route path="/trade" element={<TradeHistoryComponent />} />
              <Route path="/help" element={<HelpCenterComponent />} />
            </Routes>
          </div>
        </div>
      </Container>
       <LoginView
        show={modalShow}
        onHide={() => setModalShow(false)}
        handleaccountaddress={handleAccountAddress}
        isSign={isSign}
      />
    </>
  )
}

export default App
